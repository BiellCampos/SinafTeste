

export interface propostaseguro{
    id?:number
    cliente?:cliente
    coberturacliente?:coberturacliente[]
    valortotalpremio?:number

}

export interface cliente{
    id?:number
    nome?:string
    cpf?:string
    dtNascimento?:Date
    sexo?:boolean
    email?:string
    telefones?:string[]
    enderecos?:endereco[]
    dependenteAgregados?:dependenteAgregado[]

    
}


export interface endereco{
    cep?:string
    endereco?:string
    numero?:string
    bairro?:string
    complemento?:string
    
}

export interface cobertura{
    cobertura?:string
    percentual?:number

}

export interface coberturacliente{
    cobertura?:cobertura
    valorsegurado?:number
    valorpremio?:number

}


export interface dependenteAgregado{
    tipo?:number
    nome?:string
    cpf?:string
}
