import { Component, OnInit } from '@angular/core';
import { cliente, coberturacliente, dependenteAgregado, endereco, propostaseguro } from './models/propostaSeguro';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  ngOnInit(): void {
    this.cliente = {telefones:[],enderecos:[],dependenteAgregados:[]};
    this.endereco={};
    this.depagred={}
    this.coberturacliente={};
  }

  title = 'sinafTeste';
  cliente:cliente;
  newtel="";
  newcep="";
  newend="";
  newnum="";
  newcompl="";
  newbairro="";
  boldepagreg = 0;
  endereco:endereco;
  depagred:dependenteAgregado;
  coberturacliente:coberturacliente;
  newtipodepagreg = "";
  newnomedepagreg="";
  newcpfdepagreg="";
  propostaseguro:propostaseguro;
  newcobertura=1;

  public addTel=($event)=>{
    this.cliente.telefones.push(this.newtel);
    this.newtel="";
  };

  public delTel=(i)=>{
   this.cliente.telefones.splice(i,1);
  };

  public addend=($event)=>{
    this.endereco.cep=this.newcep;
    this.endereco.endereco=this.newend;
    this.endereco.numero=this.newnum;
    this.endereco.complemento=this.newcompl;
    this.endereco.bairro=this.newbairro;

    this.cliente.enderecos.push(this.endereco);
    this.newcep="";
    this.newend="";
    this.newnum="";
    this.newcompl="";
    this.newbairro="";
    this.endereco={};
  };
  public delend=(j)=>{
   this.cliente.enderecos.splice(j,1);
  };
  
  /**
   *  metodo para limpar lista de dependentes
   */
  public cleardepagreg(){
    this.cliente.dependenteAgregados=[];
    this.newtipodepagreg="";
    this.newnomedepagreg="";
    this.newcpfdepagreg="";
   
    this.depagred={};
    
  }

  /**
   *  metodo deletar dependente/agregado da lista
   */
  public deldepagreg=(k)=>{
    this.cliente.dependenteAgregados.splice(k,1);
   };

   public adddepagreg=($event)=>{
    this.depagred.tipo=Number(this.newtipodepagreg);
    this.depagred.nome=this.newnomedepagreg;
    this.depagred.cpf= this.newcpfdepagreg;

    this.cliente.dependenteAgregados.push(this.depagred);
    this.newtipodepagreg="";
    this.newnomedepagreg="";
    this.newcpfdepagreg="";
   
    this.depagred={};
  };
  
}
